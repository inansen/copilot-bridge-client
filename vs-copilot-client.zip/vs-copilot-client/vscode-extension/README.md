# VS Code AI Bridge for GDPR Analysis

Use VS Code's Language Model API (GitHub Copilot) from Python scripts.

## Architecture

```
Python Script → JSON Input → VS Code Extension → Copilot API → JSON Output → Python Script
```

## Setup

### 1. Install Extension (Development Mode)

```powershell
cd vscode-extension
code --install-extension .
```

Or for development:
1. Open VS Code in the `confluence` folder
2. Press `F5` to launch Extension Development Host
3. In the new window, your workspace will have the extension loaded

### 2. Install Dependencies (if needed)

```powershell
cd vscode-extension
npm install
```

### 3. Verify GitHub Copilot is Enabled

- Ensure GitHub Copilot extension is installed
- Check you're signed in with a valid Copilot subscription
- Test by opening any file and getting completions

## Usage

### Automated Workflow (Python → Extension → Python)

```powershell
python use-vscode-ai.py
```

**What it does:**
1. Reads pages from `page-tree.json`
2. Generates AI prompts → saves to `agents/ai-input.json`
3. Calls VS Code extension command (or prompts you to run it)
4. Extension processes with Copilot → saves to `agents/ai-output.json`
5. Converts results → saves to `agents/ai-findings.json`
6. Ready for `sanitize-and-migrate.py`

### Manual Workflow

1. **Generate prompts:**
   ```powershell
   python use-vscode-ai.py  # Will stop at step 2
   ```

2. **Run extension manually:**
   - Press `Ctrl+Shift+P`
   - Type: `GDPR: Analyze Pages`
   - Press Enter
   - Wait for completion notification

3. **Process results:**
   ```powershell
   python use-vscode-ai.py  # Will continue from results
   ```

## File Flow

```
page-tree.json (input)
    ↓
agents/ai-input.json (prompts for extension)
    ↓
[VS Code Extension processes with Copilot]
    ↓
agents/ai-output.json (raw Copilot responses)
    ↓
agents/ai-findings.json (formatted for migration)
    ↓
sanitize-and-migrate.py (uses findings)
```

## Extension Development

### Testing the Extension

1. Open workspace in VS Code
2. Open `vscode-extension/extension.js`
3. Press `F5` to launch Extension Development Host
4. In new window: `Ctrl+Shift+P` → `GDPR: Analyze Pages`

### Debugging

- Extension logs appear in Debug Console (F5 window)
- Check VS Code Output panel → "GDPR AI Analyzer"
- Inspect `agents/ai-output.json` for raw responses

## Troubleshooting

**"No Copilot models available"**
- Ensure GitHub Copilot extension is installed and active
- Sign in to GitHub with Copilot subscription
- Reload VS Code

**"Extension command not found"**
- Extension not loaded: Press `F5` to load in dev mode
- Or install extension: `code --install-extension vscode-extension/`

**"ai-output.json not created"**
- Extension may still be running (check notifications)
- Check Debug Console for errors
- Manually verify `agents/ai-input.json` exists

**"Invalid JSON from Copilot"**
- Copilot may return markdown-wrapped JSON
- Extension should handle this, but check raw output
- Retry the analysis

## Benefits vs Other Approaches

✅ **No API keys needed** - Uses your Copilot subscription  
✅ **Free** - Already paying for Copilot  
✅ **Fully automated** - No copy/paste required  
✅ **Same model** - Uses GitHub Copilot's GPT-4  
✅ **Integrated** - Runs directly in VS Code  

❌ **Requires VS Code** - Can't run headless  
❌ **Dev mode** - Extension needs to be loaded  

## Alternative: Use OpenAI Directly

If you prefer fully automated without VS Code dependency:

```powershell
# Add to .env
OPENAI_API_KEY=sk-your-key-here

# Then just run
python sanitize-and-migrate.py
```

The script auto-detects OpenAI key and uses API instead.
